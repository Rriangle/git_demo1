using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using GameSpace.Areas.MiniGame.Services;
using GameSpace.Areas.MiniGame.Models;
using GameSpace.Areas.MiniGame.Filters;

namespace GameSpace.Areas.MiniGame.Controllers
{
    [Area("MiniGame")]
    [Authorize(AuthenticationSchemes = "AdminCookie")]
    [MiniGameModulePermission("UserWallet")]
    public class AdminWalletController : Controller
    {
        private readonly IMiniGameAdminService _adminService;

        public AdminWalletController(IMiniGameAdminService adminService)
        {
            _adminService = adminService;
        }

        public async Task<IActionResult> Index(WalletQueryModel query)
        {
            if (query.PageNumber <= 0) query.PageNumber = 1;
            if (query.PageSize <= 0) query.PageSize = 10;

            var wallets = await _adminService.GetWalletsAsync(query);
            var walletSummary = await _adminService.GetWalletSummaryAsync();

            var viewModel = new AdminWalletIndexViewModel
            {
                Wallets = wallets,
                WalletSummary = walletSummary,
                Query = query
            };

            return View(viewModel);
        }

        public async Task<IActionResult> Details(int userId)
        {
            var walletDetail = await _adminService.GetWalletDetailAsync(userId);

            var viewModel = new AdminWalletDetailsViewModel
            {
                WalletDetail = walletDetail ?? new WalletDetailReadModel()
            };

            return View(viewModel);
        }

        public async Task<IActionResult> Statistics()
        {
            var walletSummary = await _adminService.GetWalletSummaryAsync();
            var wallets = await _adminService.GetWalletsAsync(new WalletQueryModel { PageSize = 10 });

            var viewModel = new AdminWalletStatisticsViewModel
            {
                Summary = walletSummary,
                TopWallets = wallets.Items.ToList()
            };

            return View(viewModel);
        }

        // GET: MiniGame/AdminWallet/AdjustPoints
        public IActionResult AdjustPoints()
        {
            var viewModel = new AdminWalletAdjustPointsViewModel();
            return View(viewModel);
        }

        // POST: MiniGame/AdminWallet/AdjustPoints
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AdjustPoints(AdminWalletAdjustPointsViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            try
            {
                var success = await _adminService.AdjustUserPointsAsync(model.UserId, model.Points, model.Reason);

                if (success)
                {
                    TempData["SuccessMessage"] = "會員點數調整成功";
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    TempData["ErrorMessage"] = "會員點數調整失敗";
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = $"會員點數調整失敗：{ex.Message}";
            }

            return View(model);
        }

        // GET: MiniGame/AdminWallet/History/5
        public async Task<IActionResult> History(int userId)
        {
            var transactionHistory = await _adminService.GetUserTransactionHistoryAsync(userId);
            var userInfo = await _adminService.GetUserInfoAsync(userId);

            var viewModel = new AdminWalletHistoryViewModel
            {
                UserInfo = userInfo,
                TransactionHistory = transactionHistory.ToList()
            };

            return View(viewModel);
        }
    }

    // ViewModels
    public class AdminWalletAdjustPointsViewModel
    {
        [Required(ErrorMessage = "請選擇用戶")]
        public int UserId { get; set; }

        [Required(ErrorMessage = "請輸入點數")]
        [Range(-999999, 999999, ErrorMessage = "點數必須在 -999999 到 999999 之間")]
        public int Points { get; set; }

        [Required(ErrorMessage = "請輸入調整原因")]
        [StringLength(200, ErrorMessage = "調整原因不能超過 200 個字元")]
        public string Reason { get; set; } = string.Empty;

        public string Sidebar { get; set; } = "admin";
    }

    public class AdminWalletHistoryViewModel
    {
        public UserInfoReadModel UserInfo { get; set; } = new();
        public List<WalletTransactionReadModel> TransactionHistory { get; set; } = new();
        public string Sidebar { get; set; } = "admin";
    }
}
