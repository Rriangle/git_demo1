using Microsoft.AspNetCore.Mvc;
using GameSpace.Areas.MiniGame.Services;
using GameSpace.Areas.MiniGame.Models;
using GameSpace.Models;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Reflection;

namespace GameSpace.Areas.MiniGame.Controllers
{
    [Area("MiniGame")]
    [Authorize(AuthenticationSchemes = "AdminCookie")]
    [MiniGameAdminAuthorize]
    public class AdminDiagnosticsController : Controller
    {
        private readonly GameSpacedatabaseContext _context;
        private readonly IWebHostEnvironment _environment;

        public AdminDiagnosticsController(GameSpacedatabaseContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        [HttpGet]
        public async Task<IActionResult> FieldCoverage()
        {
            try
            {
                var tables = new List<object>();
                var tableMappings = new Dictionary<string, Type>
                {
                    { "Users", typeof(User) },
                    { "Pets", typeof(Pet) },
                    { "MiniGames", typeof(GameSpace.Models.MiniGame) },
                    { "UserSignInStats", typeof(UserSignInStat) },
                    { "Coupons", typeof(Coupon) },
                    { "Evouchers", typeof(Evoucher) },
                    { "UserWallets", typeof(UserWallet) },
                    { "WalletHistories", typeof(WalletHistory) }
                };

                foreach (var mapping in tableMappings)
                {
                    var tableName = mapping.Key;
                    var entityType = mapping.Value;
                    
                    // 取得實體屬性
                    var entityProperties = entityType.GetProperties()
                        .Where(p => p.CanRead && p.CanWrite && !p.PropertyType.IsGenericType)
                        .Select(p => p.Name)
                        .ToList();
                    
                    // 從資料庫取得實際欄位
                    var schemaFields = await GetSchemaFieldsFromDatabase(tableName);
                    
                    // 檢查 View 檔案
                    var viewFields = GetViewFieldsFromFiles(tableName);
                    
                    var missingInView = schemaFields.Except(viewFields).ToList();
                    var missingInEntity = schemaFields.Except(entityProperties).ToList();
                    
                    tables.Add(new
                    {
                        table = tableName,
                        schemaCount = schemaFields.Count,
                        entityCount = entityProperties.Count,
                        viewFieldCount = viewFields.Count,
                        missingInView = missingInView,
                        missingInEntity = missingInEntity,
                        schemaFields = schemaFields,
                        entityFields = entityProperties,
                        viewFields = viewFields
                    });
                }
                
                return Json(new { 
                    success = true,
                    tables = tables,
                    message = "欄位覆蓋率分析完成"
                });
            }
            catch (Exception ex)
            {
                return Json(new { 
                    success = false,
                    error = ex.Message,
                    stackTrace = ex.StackTrace 
                });
            }
        }

        [HttpGet]
        public async Task<IActionResult> DatabaseConnection()
        {
            try
            {
                var canConnect = await _context.Database.CanConnectAsync();
                var connectionString = _context.Database.GetConnectionString();
                
                // 嘗試執行簡單查詢測試連線
                var userCount = 0;
                if (canConnect)
                {
                    userCount = await _context.Users.CountAsync();
                }
                
                return Json(new { 
                    canConnect = canConnect,
                    connectionString = connectionString?.Substring(0, Math.Min(50, connectionString?.Length ?? 0)) + "...",
                    userCount = userCount,
                    message = canConnect ? "資料庫連接成功" : "資料庫連接失敗",
                    timestamp = DateTime.Now
                });
            }
            catch (Exception ex)
            {
                return Json(new { 
                    canConnect = false,
                    error = ex.Message,
                    message = "資料庫連接測試失敗",
                    timestamp = DateTime.Now
                });
            }
        }

        [HttpGet]
        public async Task<IActionResult> MiniGameTables()
        {
            try
            {
                var miniGameTables = new List<object>();
                
                // 檢查 MiniGame 相關表格的實際資料
                var miniGameCount = await _context.MiniGames.CountAsync();
                var petCount = await _context.Pets.CountAsync();
                var userSignInCount = await _context.UserSignInStats.CountAsync();
                var couponCount = await _context.Coupons.CountAsync();
                var evoucherCount = await _context.Evouchers.CountAsync();
                var userWalletCount = await _context.UserWallets.CountAsync();
                var userCount = await _context.Users.CountAsync();

                miniGameTables.Add(new { table = "MiniGames", count = miniGameCount });
                miniGameTables.Add(new { table = "Pets", count = petCount });
                miniGameTables.Add(new { table = "UserSignInStats", count = userSignInCount });
                miniGameTables.Add(new { table = "Coupons", count = couponCount });
                miniGameTables.Add(new { table = "Evouchers", count = evoucherCount });
                miniGameTables.Add(new { table = "UserWallets", count = userWalletCount });
                miniGameTables.Add(new { table = "Users", count = userCount });

                return Json(new { 
                    success = true,
                    tables = miniGameTables,
                    totalRecords = miniGameTables.Sum(t => (int)t.GetType().GetProperty("count").GetValue(t)),
                    timestamp = DateTime.Now
                });
            }
            catch (Exception ex)
            {
                return Json(new { 
                    success = false,
                    error = ex.Message,
                    message = "無法讀取表格資料"
                });
            }
        }

        [HttpGet]
        public async Task<IActionResult> SampleData(string tableName = "Users", int take = 5)
        {
            try
            {
                object sampleData = null;
                
                switch (tableName.ToLower())
                {
                    case "users":
                        sampleData = await _context.Users
                            .Take(take)
                            .Select(u => new { u.UserId, u.UserName, u.UserAccount })
                            .ToListAsync();
                        break;
                    case "pets":
                        sampleData = await _context.Pets
                            .Take(take)
                            .Select(p => new { p.PetId, p.PetName, p.Level, p.UserId })
                            .ToListAsync();
                        break;
                    case "minigames":
                        sampleData = await _context.MiniGames
                            .Take(take)
                            .Select(m => new { m.PlayId, m.UserId, m.PetId, m.Level, m.Result })
                            .ToListAsync();
                        break;
                    case "userwallets":
                        sampleData = await _context.UserWallets
                            .Take(take)
                            .Select(w => new { w.User_Id, w.User_Point })
                            .ToListAsync();
                        break;
                    default:
                        return Json(new { error = "不支援的表格名稱" });
                }
                
                return Json(new { 
                    success = true,
                    tableName = tableName,
                    sampleData = sampleData,
                    message = $"成功讀取 {tableName} 的範例資料"
                });
            }
            catch (Exception ex)
            {
                return Json(new { 
                    success = false,
                    error = ex.Message,
                    message = "無法讀取範例資料"
                });
            }
        }

        [HttpGet]
        public IActionResult SeedData()
        {
            try
            {
                var seedDataPath = Path.Combine(_environment.ContentRootPath, "..", "..", "..", "..", "..", "schema", "seedMiniGameArea.json");
                
                if (!System.IO.File.Exists(seedDataPath))
                {
                    return Json(new { 
                        success = false,
                        error = "種子數據文件不存在", 
                        path = seedDataPath 
                    });
                }

                var seedData = System.IO.File.ReadAllText(seedDataPath);
                var seedDataJson = JsonSerializer.Deserialize<Dictionary<string, object>>(seedData);
                
                // 統計每個表格的記錄數
                var tableStats = new Dictionary<string, int>();
                if (seedDataJson != null)
                {
                    foreach (var kvp in seedDataJson)
                    {
                        if (kvp.Value is JsonElement element && element.ValueKind == JsonValueKind.Array)
                        {
                            tableStats[kvp.Key] = element.GetArrayLength();
                        }
                    }
                }
                
                return Json(new { 
                    success = true,
                    data = seedDataJson,
                    tableStats = tableStats,
                    message = "種子數據讀取成功"
                });
            }
            catch (Exception ex)
            {
                return Json(new { 
                    success = false,
                    error = ex.Message 
                });
            }
        }

        private async Task<List<string>> GetSchemaFieldsFromDatabase(string tableName)
        {
            try
            {
                var connectionString = _context.Database.GetConnectionString();
                var fields = new List<string>();
                
                using (var connection = new SqlConnection(connectionString))
                {
                    await connection.OpenAsync();
                    
                    var query = @"
                        SELECT COLUMN_NAME 
                        FROM INFORMATION_SCHEMA.COLUMNS 
                        WHERE TABLE_NAME = @tableName
                        ORDER BY ORDINAL_POSITION";
                    
                    using (var command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@tableName", tableName);
                        
                        using (var reader = await command.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                fields.Add(reader.GetString("COLUMN_NAME"));
                            }
                        }
                    }
                }
                
                return fields;
            }
            catch (Exception ex)
            {
                // 如果無法連接資料庫，回傳空列表
                return new List<string>();
            }
        }

        private List<string> GetViewFieldsFromFiles(string tableName)
        {
            try
            {
                var fields = new List<string>();
                var viewsPath = Path.Combine(_environment.ContentRootPath, "Areas", "MiniGame", "Views");
                
                // 尋找相關的 View 檔案
                var searchPatterns = new[] { $"{tableName}*.cshtml", $"*{tableName}*.cshtml" };
                
                foreach (var pattern in searchPatterns)
                {
                    if (Directory.Exists(viewsPath))
                    {
                        var files = Directory.GetFiles(viewsPath, pattern, SearchOption.AllDirectories);
                        
                        foreach (var file in files)
                        {
                            var content = System.IO.File.ReadAllText(file);
                            
                            // 簡單的欄位提取 (尋找 @Model.PropertyName 或 @item.PropertyName 模式)
                            var modelMatches = System.Text.RegularExpressions.Regex.Matches(
                                content, @"@(?:Model|item)\.(\w+)", 
                                System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                            
                            foreach (System.Text.RegularExpressions.Match match in modelMatches)
                            {
                                var fieldName = match.Groups[1].Value;
                                if (!fields.Contains(fieldName))
                                {
                                    fields.Add(fieldName);
                                }
                            }
                        }
                    }
                }
                
                return fields.Distinct().ToList();
            }
            catch (Exception)
            {
                // 如果無法讀取 View 檔案，回傳空列表
                return new List<string>();
            }
        }
    }
}
