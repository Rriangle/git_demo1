namespace GameSpace.Areas.MiniGame.Services
{
    public class MiniGameAdminGate : IMiniGameAdminGate { /* compile-only */ }
}
