namespace GameSpace.Areas.MiniGame.Services
{
    public interface IMiniGameAdminGate { /* compile-only */ }
}
