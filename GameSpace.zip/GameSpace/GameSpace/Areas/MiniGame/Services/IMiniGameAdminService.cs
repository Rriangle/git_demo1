using GameSpace.Models;
using GameSpace.Areas.MiniGame.Models;

namespace GameSpace.Areas.MiniGame.Services
{
    public interface IMiniGameAdminService
    {
        #region User_Wallet 模組服務

        Task<WalletSummaryReadModel> GetWalletSummaryAsync();
        Task<PagedResult<WalletReadModel>> GetWalletsAsync(WalletQueryModel query);
        Task<WalletDetailReadModel?> GetWalletDetailAsync(int userId);
        
        // 會員點數管理
        Task<PagedResult<WalletReadModel>> QueryUserPointsAsync(WalletQueryModel query);
        Task<bool> AdjustUserPointsAsync(int userId, int points, string reason);
        Task<IEnumerable<WalletTransactionReadModel>> GetUserTransactionHistoryAsync(int userId);
        
        // 商城優惠券管理
        Task<PagedResult<CouponReadModel>> QueryUserCouponsAsync(CouponQueryModel query);
        Task<bool> AdjustUserCouponsAsync(int userId, int couponId, int quantity, string action);
        Task<bool> IssueCouponToUserAsync(int userId, int couponId, int quantity);
        Task<bool> RemoveCouponFromUserAsync(int userId, int couponId, int quantity);
        
        // 電子禮券管理
        Task<PagedResult<EVoucherReadModel>> QueryUserEVouchersAsync(EVoucherQueryModel query);
        Task<bool> AdjustUserEVouchersAsync(int userId, int eVoucherId, int quantity, string action);
        Task<bool> IssueEVoucherToUserAsync(int userId, int eVoucherId, int quantity);
        Task<bool> RemoveEVoucherFromUserAsync(int userId, int eVoucherId, int quantity);

        #endregion

        #region UserSignInStat 模組服務

        Task<SignInSummaryReadModel> GetSignInSummaryAsync();
        Task<PagedResult<SignInStatsReadModel>> GetSignInStatsAsync(SignInQueryModel query);
        Task<IEnumerable<UserSignInHistoryReadModel>> GetUserSignInHistoryAsync(int userId);
        Task<UserInfoReadModel> GetUserInfoAsync(int userId);
        Task<SignInStatisticsReadModel> GetSignInStatisticsAsync();
        
        // 簽到規則管理
        Task<SignInRuleReadModel> GetSignInRulesAsync();
        Task<bool> UpdateSignInRulesAsync(SignInRuleUpdateModel model);
        
        // 手動調整簽到紀錄
        Task<bool> AddUserSignInRecordAsync(int userId, DateTime signInDate);
        Task<bool> RemoveUserSignInRecordAsync(int userId, DateTime signInDate);

        #endregion

        #region Pet 模組服務

        Task<PetSummaryReadModel> GetPetSummaryAsync();
        Task<PagedResult<PetReadModel>> GetPetsAsync(PetQueryModel query);
        Task<PetDetailReadModel?> GetPetDetailAsync(int petId);
        Task<bool> UpdatePetAsync(int petId, PetUpdateModel model);
        Task<bool> DeletePetAsync(int petId);

        #endregion

        #region Game 模組服務

        Task<GameSummaryReadModel> GetGameSummaryAsync();
        Task<PagedResult<GameRecordReadModel>> GetGameRecordsAsync(GameQueryModel query);
        Task<GameDetailReadModel?> GetGameDetailAsync(int playId);

        #endregion

        #region 系統診斷服務

        Task<SystemDiagnosticsReadModel> GetSystemDiagnosticsAsync();
        Task<bool> TestDatabaseConnectionAsync();
        Task<bool> TestEmailServiceAsync();
        Task<bool> TestFileSystemAsync();

        #endregion
    }
}
