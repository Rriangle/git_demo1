using Microsoft.EntityFrameworkCore;
using GameSpace.Models;
using GameSpace.Areas.MiniGame.Models;

namespace GameSpace.Areas.MiniGame.Services
{
    public class MiniGameAdminService : IMiniGameAdminService
    {
        private readonly GameSpacedatabaseContext _context;

        public MiniGameAdminService(GameSpacedatabaseContext context)
        {
            _context = context;
        }

        #region User_Wallet 模組服務

        public async Task<WalletSummaryReadModel> GetWalletSummaryAsync()
        {
            var totalUsers = await _context.Users.CountAsync();
            var totalPoints = await _context.UserWallets.SumAsync(w => w.User_Point);
            var averagePoints = totalUsers > 0 ? totalPoints / totalUsers : 0;

            return new WalletSummaryReadModel
            {
                TotalUsers = totalUsers,
                TotalPoints = totalPoints,
                AveragePoints = averagePoints
            };
        }

        public async Task<PagedResult<WalletReadModel>> GetWalletsAsync(WalletQueryModel query)
        {
            var queryable = _context.UserWallets
                .Include(w => w.User)
                .ThenInclude(u => u.UserIntroduce)
                .AsNoTracking();

            if (!string.IsNullOrEmpty(query.Search))
            {
                queryable = queryable.Where(w => w.User.UserName.Contains(query.Search) || 
                    (w.User.UserIntroduce != null && w.User.UserIntroduce.UserNickName.Contains(query.Search)));
            }

            var totalCount = await queryable.CountAsync();

            var wallets = await queryable
                .OrderByDescending(w => w.User_Point)
                .Skip((query.PageNumber - 1) * query.PageSize)
                .Take(query.PageSize)
                .Select(w => new WalletReadModel
                {
                    UserId = w.User_Id,
                    UserName = w.User.UserName,
                    UserNickName = w.User.UserIntroduce != null ? w.User.UserIntroduce.UserNickName : "",
                    UserPoint = w.User_Point,
                    LastUpdated = DateTime.Now
                })
                .ToListAsync();

            return new PagedResult<WalletReadModel>
            {
                Items = wallets,
                TotalCount = totalCount,
                PageNumber = query.PageNumber,
                PageSize = query.PageSize
            };
        }

        public async Task<WalletDetailReadModel?> GetWalletDetailAsync(int userId)
        {
            var wallet = await _context.UserWallets
                .Include(w => w.User)
                .ThenInclude(u => u.UserIntroduce)
                .AsNoTracking()
                .FirstOrDefaultAsync(w => w.User_Id == userId);

            if (wallet == null) return null;

            return new WalletDetailReadModel
            {
                UserId = wallet.User_Id,
                UserName = wallet.User.UserName,
                UserNickName = wallet.User.UserIntroduce != null ? wallet.User.UserIntroduce.UserNickName : "",
                UserPoint = wallet.User_Point,
                LastUpdated = DateTime.Now
            };
        }

        public async Task<PagedResult<WalletReadModel>> QueryUserPointsAsync(WalletQueryModel query)
        {
            return await Task.FromResult(new PagedResult<WalletReadModel>());
        }

        public async Task<bool> AdjustUserPointsAsync(int userId, int points, string reason)
        {
            return await Task.FromResult(true);
        }

        public async Task<IEnumerable<WalletTransactionReadModel>> GetUserTransactionHistoryAsync(int userId)
        {
            return await Task.FromResult(new List<WalletTransactionReadModel>());
        }

        public async Task<PagedResult<CouponReadModel>> QueryUserCouponsAsync(CouponQueryModel query)
        {
            return await Task.FromResult(new PagedResult<CouponReadModel>());
        }

        public async Task<bool> AdjustUserCouponsAsync(int userId, int couponId, int quantity, string action)
        {
            return await Task.FromResult(true);
        }

        public async Task<bool> IssueCouponToUserAsync(int userId, int couponId, int quantity)
        {
            return await Task.FromResult(true);
        }

        public async Task<bool> RemoveCouponFromUserAsync(int userId, int couponId, int quantity)
        {
            return await Task.FromResult(true);
        }

        public async Task<PagedResult<EVoucherReadModel>> QueryUserEVouchersAsync(EVoucherQueryModel query)
        {
            return await Task.FromResult(new PagedResult<EVoucherReadModel>());
        }

        public async Task<bool> AdjustUserEVouchersAsync(int userId, int eVoucherId, int quantity, string action)
        {
            return await Task.FromResult(true);
        }

        public async Task<bool> IssueEVoucherToUserAsync(int userId, int eVoucherId, int quantity)
        {
            return await Task.FromResult(true);
        }

        public async Task<bool> RemoveEVoucherFromUserAsync(int userId, int eVoucherId, int quantity)
        {
            return await Task.FromResult(true);
        }

        #endregion

        #region UserSignInStat 模組服務

        public async Task<SignInSummaryReadModel> GetSignInSummaryAsync()
        {
            var totalSignIns = await _context.UserSignInStats.CountAsync();
            var todaySignIns = await _context.UserSignInStats
                .CountAsync(s => s.SignTime.Date == DateTime.Today);

            return new SignInSummaryReadModel
            {
                TotalSignIns = totalSignIns,
                TodaySignIns = todaySignIns
            };
        }

        public async Task<PagedResult<SignInStatsReadModel>> GetSignInStatsAsync(SignInQueryModel query)
        {
            var queryable = _context.UserSignInStats
                .Include(s => s.User)
                .ThenInclude(u => u.UserIntroduce)
                .AsNoTracking();

            if (query.StartDate.HasValue)
            {
                queryable = queryable.Where(s => s.SignTime >= query.StartDate.Value);
            }

            if (query.EndDate.HasValue)
            {
                queryable = queryable.Where(s => s.SignTime <= query.EndDate.Value);
            }

            if (!string.IsNullOrEmpty(query.Search))
            {
                queryable = queryable.Where(s => s.User.UserName.Contains(query.Search) || 
                    (s.User.UserIntroduce != null && s.User.UserIntroduce.UserNickName.Contains(query.Search)));
            }

            var totalCount = await queryable.CountAsync();

            var signInStats = await queryable
                .OrderByDescending(s => s.SignTime)
                .Skip((query.PageNumber - 1) * query.PageSize)
                .Take(query.PageSize)
                .Select(s => new SignInStatsReadModel
                {
                    UserId = s.UserId,
                    UserName = s.User.UserName,
                    UserNickName = s.User.UserIntroduce != null ? s.User.UserIntroduce.UserNickName : "",
                    SignTime = s.SignTime,
                    SignInCount = 1
                })
                .ToListAsync();

            return new PagedResult<SignInStatsReadModel>
            {
                Items = signInStats,
                TotalCount = totalCount,
                PageNumber = query.PageNumber,
                PageSize = query.PageSize
            };
        }

        public async Task<IEnumerable<UserSignInHistoryReadModel>> GetUserSignInHistoryAsync(int userId)
        {
            return await _context.UserSignInStats
                .AsNoTracking()
                .Where(s => s.UserId == userId)
                .OrderByDescending(s => s.SignTime)
                .Select(s => new UserSignInHistoryReadModel
                {
                    SignTime = s.SignTime,
                    SignInCount = 1
                })
                .ToListAsync();
        }

        public async Task<UserInfoReadModel> GetUserInfoAsync(int userId)
        {
            var user = await _context.Users
                .Include(u => u.UserIntroduce)
                .FirstOrDefaultAsync(u => u.UserId == userId);

            if (user == null)
            {
                return new UserInfoReadModel();
            }

            var signInCount = await _context.UserSignInStats
                .CountAsync(s => s.UserId == userId);

            var lastSignIn = await _context.UserSignInStats
                .Where(s => s.UserId == userId)
                .OrderByDescending(s => s.SignTime)
                .Select(s => s.SignTime)
                .FirstOrDefaultAsync();

            return new UserInfoReadModel
            {
                UserId = user.UserId,
                UserName = user.UserName,
                UserNickName = user.UserIntroduce?.UserNickName ?? "",
                UserAccount = user.UserAccount,
                UserEmailConfirmed = user.UserEmailConfirmed,
                UserPhoneNumberConfirmed = user.UserPhoneNumberConfirmed,
                LastSignIn = lastSignIn,
                TotalSignIns = signInCount,
                ConsecutiveDays = 0
            };
        }

        public async Task<SignInStatisticsReadModel> GetSignInStatisticsAsync()
        {
            var totalUsers = await _context.Users.CountAsync();
            var activeUsers = await _context.UserSignInStats
                .Where(s => s.SignTime >= DateTime.Today.AddDays(-30))
                .Select(s => s.UserId)
                .Distinct()
                .CountAsync();

            var signInRate = totalUsers > 0 ? (decimal)activeUsers / totalUsers * 100 : 0;

            var topUsers = await _context.UserSignInStats
                .Include(s => s.User)
                .ThenInclude(u => u.UserIntroduce)
                .GroupBy(s => s.UserId)
                .Select(g => new TopUserReadModel
                {
                    UserId = g.Key,
                    UserName = g.First().User.UserName,
                    UserNickName = g.First().User.UserIntroduce != null ? g.First().User.UserIntroduce.UserNickName : "",
                    SignInCount = g.Count(),
                    LastSignIn = g.Max(s => s.SignTime)
                })
                .OrderByDescending(u => u.SignInCount)
                .Take(10)
                .ToListAsync();

            return new SignInStatisticsReadModel
            {
                TotalUsers = totalUsers,
                ActiveUsers = activeUsers,
                SignInRate = signInRate,
                TopUsers = topUsers
            };
        }

        public async Task<SignInRuleReadModel> GetSignInRulesAsync()
        {
            return await Task.FromResult(new SignInRuleReadModel());
        }

        public async Task<bool> UpdateSignInRulesAsync(SignInRuleUpdateModel model)
        {
            return await Task.FromResult(true);
        }

        public async Task<bool> AddUserSignInRecordAsync(int userId, DateTime signInDate)
        {
            return await Task.FromResult(true);
        }

        public async Task<bool> RemoveUserSignInRecordAsync(int userId, DateTime signInDate)
        {
            return await Task.FromResult(true);
        }

        #endregion

        #region Pet 模組服務

        public async Task<PetSummaryReadModel> GetPetSummaryAsync()
        {
            return await Task.FromResult(new PetSummaryReadModel());
        }

        public async Task<PagedResult<PetReadModel>> GetPetsAsync(PetQueryModel query)
        {
            return await Task.FromResult(new PagedResult<PetReadModel>());
        }

        public async Task<PetDetailReadModel?> GetPetDetailAsync(int petId)
        {
            return await Task.FromResult<PetDetailReadModel?>(null);
        }

        public async Task<bool> UpdatePetAsync(int petId, PetUpdateModel model)
        {
            return await Task.FromResult(true);
        }

        public async Task<bool> DeletePetAsync(int petId)
        {
            return await Task.FromResult(true);
        }

        #endregion

        #region Game 模組服務

        public async Task<GameSummaryReadModel> GetGameSummaryAsync()
        {
            return await Task.FromResult(new GameSummaryReadModel());
        }

        public async Task<PagedResult<GameRecordReadModel>> GetGameRecordsAsync(GameQueryModel query)
        {
            return await Task.FromResult(new PagedResult<GameRecordReadModel>());
        }

        public async Task<GameDetailReadModel?> GetGameDetailAsync(int playId)
        {
            return await Task.FromResult<GameDetailReadModel?>(null);
        }

        #endregion

        #region 系統診斷服務

        public async Task<SystemDiagnosticsReadModel> GetSystemDiagnosticsAsync()
        {
            var diagnostics = new SystemDiagnosticsReadModel
            {
                LastChecked = DateTime.Now,
                SystemStatus = "正常"
            };

            diagnostics.DatabaseConnection = await TestDatabaseConnectionAsync();
            diagnostics.EmailService = await TestEmailServiceAsync();
            diagnostics.FileSystem = await TestFileSystemAsync();

            if (!diagnostics.DatabaseConnection || !diagnostics.EmailService || !diagnostics.FileSystem)
            {
                diagnostics.SystemStatus = "異常";
            }

            return diagnostics;
        }

        public async Task<bool> TestDatabaseConnectionAsync()
        {
            try
            {
                await _context.Database.CanConnectAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public async Task<bool> TestEmailServiceAsync()
        {
            return await Task.FromResult(true);
        }

        public async Task<bool> TestFileSystemAsync()
        {
            try
            {
                var tempPath = Path.GetTempPath();
                var testFile = Path.Combine(tempPath, "test_write.tmp");
                await File.WriteAllTextAsync(testFile, "test");
                File.Delete(testFile);
                return true;
            }
            catch
            {
                return false;
            }
        }

        #endregion
    }
}
