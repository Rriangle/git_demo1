using GameSpace.Models;
using System.ComponentModel.DataAnnotations;

namespace GameSpace.Areas.MiniGame.Models
{
    // 錢包交易紀錄
    public class WalletTransactionReadModel
    {
        public int TransactionId { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string TransactionType { get; set; } = string.Empty;
        public int Amount { get; set; }
        public int BalanceAfter { get; set; }
        public string Description { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
    }

    // 商城優惠券相關
    public class CouponReadModel
    {
        public int CouponId { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string CouponName { get; set; } = string.Empty;
        public string CouponCode { get; set; } = string.Empty;
        public decimal DiscountValue { get; set; }
        public string DiscountType { get; set; } = string.Empty;
        public int Quantity { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public bool IsUsed { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class CouponQueryModel
    {
        public string Search { get; set; } = string.Empty;
        public int? UserId { get; set; }
        public bool? IsUsed { get; set; }
        public DateTime? ExpiryDateFrom { get; set; }
        public DateTime? ExpiryDateTo { get; set; }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 10;
    }

    // 電子禮券相關
    public class EVoucherReadModel
    {
        public int EVoucherId { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string EVoucherName { get; set; } = string.Empty;
        public string EVoucherCode { get; set; } = string.Empty;
        public decimal Value { get; set; }
        public int Quantity { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public bool IsUsed { get; set; }
        public DateTime CreatedAt { get; set; }
    }

    public class EVoucherQueryModel
    {
        public string Search { get; set; } = string.Empty;
        public int? UserId { get; set; }
        public bool? IsUsed { get; set; }
        public DateTime? ExpiryDateFrom { get; set; }
        public DateTime? ExpiryDateTo { get; set; }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 10;
    }

    // 簽到規則相關
    public class SignInRuleReadModel
    {
        public int RuleId { get; set; }
        public int DailyPoints { get; set; }
        public int ConsecutiveBonus { get; set; }
        public int MaxConsecutiveDays { get; set; }
        public int WeeklyBonus { get; set; }
        public int MonthlyBonus { get; set; }
        public bool IsActive { get; set; }
        public DateTime LastUpdated { get; set; }
    }

    public class SignInRuleUpdateModel
    {
        [Required(ErrorMessage = "每日簽到點數不能為空")]
        [Range(1, 1000, ErrorMessage = "每日簽到點數必須在 1-1000 之間")]
        public int DailyPoints { get; set; }

        [Required(ErrorMessage = "連續簽到獎勵不能為空")]
        [Range(0, 500, ErrorMessage = "連續簽到獎勵必須在 0-500 之間")]
        public int ConsecutiveBonus { get; set; }

        [Required(ErrorMessage = "最大連續天數不能為空")]
        [Range(1, 30, ErrorMessage = "最大連續天數必須在 1-30 之間")]
        public int MaxConsecutiveDays { get; set; }

        [Required(ErrorMessage = "週獎勵不能為空")]
        [Range(0, 1000, ErrorMessage = "週獎勵必須在 0-1000 之間")]
        public int WeeklyBonus { get; set; }

        [Required(ErrorMessage = "月獎勵不能為空")]
        [Range(0, 2000, ErrorMessage = "月獎勵必須在 0-2000 之間")]
        public int MonthlyBonus { get; set; }

        public bool IsActive { get; set; } = true;
    }

    // 寵物規則相關
    public class PetRuleReadModel
    {
        public int RuleId { get; set; }
        public int MaxPetsPerUser { get; set; }
        public int BaseExpPerLevel { get; set; }
        public decimal ExpMultiplier { get; set; }
        public int MaxLevel { get; set; }
        public int HappinessDecayRate { get; set; }
        public int HealthDecayRate { get; set; }
        public int HungerDecayRate { get; set; }
        public bool IsActive { get; set; }
        public DateTime LastUpdated { get; set; }
    }

    public class PetRuleUpdateModel
    {
        [Required(ErrorMessage = "每用戶最大寵物數量不能為空")]
        [Range(1, 10, ErrorMessage = "每用戶最大寵物數量必須在 1-10 之間")]
        public int MaxPetsPerUser { get; set; }

        [Required(ErrorMessage = "每級基礎經驗不能為空")]
        [Range(10, 1000, ErrorMessage = "每級基礎經驗必須在 10-1000 之間")]
        public int BaseExpPerLevel { get; set; }

        [Required(ErrorMessage = "經驗倍數不能為空")]
        [Range(1.0, 5.0, ErrorMessage = "經驗倍數必須在 1.0-5.0 之間")]
        public decimal ExpMultiplier { get; set; }

        [Required(ErrorMessage = "最大等級不能為空")]
        [Range(1, 100, ErrorMessage = "最大等級必須在 1-100 之間")]
        public int MaxLevel { get; set; }

        [Required(ErrorMessage = "快樂度衰減率不能為空")]
        [Range(1, 20, ErrorMessage = "快樂度衰減率必須在 1-20 之間")]
        public int HappinessDecayRate { get; set; }

        [Required(ErrorMessage = "健康度衰減率不能為空")]
        [Range(1, 20, ErrorMessage = "健康度衰減率必須在 1-20 之間")]
        public int HealthDecayRate { get; set; }

        [Required(ErrorMessage = "飢餓度衰減率不能為空")]
        [Range(1, 20, ErrorMessage = "飢餓度衰減率必須在 1-20 之間")]
        public int HungerDecayRate { get; set; }

        public bool IsActive { get; set; } = true;
    }

    // 寵物更新相關
    public class PetUpdateModel
    {
        [Required(ErrorMessage = "寵物名稱不能為空")]
        [StringLength(50, ErrorMessage = "寵物名稱不能超過 50 個字元")]
        public string PetName { get; set; } = string.Empty;

        [StringLength(100, ErrorMessage = "寵物類型不能超過 100 個字元")]
        public string? PetType { get; set; }

        [Range(1, 100, ErrorMessage = "寵物等級必須在 1-100 之間")]
        public int PetLevel { get; set; }

        [Range(0, 999999, ErrorMessage = "寵物經驗必須在 0-999999 之間")]
        public int PetExperience { get; set; }

        [Range(0, 100, ErrorMessage = "快樂度必須在 0-100 之間")]
        public int PetHappiness { get; set; }

        [Range(0, 100, ErrorMessage = "健康度必須在 0-100 之間")]
        public int PetHealth { get; set; }

        [Range(0, 100, ErrorMessage = "飢餓度必須在 0-100 之間")]
        public int PetHunger { get; set; }
    }

    // 遊戲規則相關
    public class GameRuleReadModel
    {
        public int RuleId { get; set; }
        public int BasePointsPerLevel { get; set; }
        public decimal PointsMultiplier { get; set; }
        public int MaxLevel { get; set; }
        public int PetBonusMultiplier { get; set; }
        public int DailyPlayLimit { get; set; }
        public bool IsActive { get; set; }
        public DateTime LastUpdated { get; set; }
    }

    public class GameRuleUpdateModel
    {
        [Required(ErrorMessage = "每級基礎點數不能為空")]
        [Range(1, 1000, ErrorMessage = "每級基礎點數必須在 1-1000 之間")]
        public int BasePointsPerLevel { get; set; }

        [Required(ErrorMessage = "點數倍數不能為空")]
        [Range(1.0, 5.0, ErrorMessage = "點數倍數必須在 1.0-5.0 之間")]
        public decimal PointsMultiplier { get; set; }

        [Required(ErrorMessage = "最大等級不能為空")]
        [Range(1, 50, ErrorMessage = "最大等級必須在 1-50 之間")]
        public int MaxLevel { get; set; }

        [Required(ErrorMessage = "寵物獎勵倍數不能為空")]
        [Range(1, 3, ErrorMessage = "寵物獎勵倍數必須在 1-3 之間")]
        public int PetBonusMultiplier { get; set; }

        [Required(ErrorMessage = "每日遊戲次數限制不能為空")]
        [Range(1, 100, ErrorMessage = "每日遊戲次數限制必須在 1-100 之間")]
        public int DailyPlayLimit { get; set; }

        public bool IsActive { get; set; } = true;
    }
}
