using GameSpace.Models;

namespace GameSpace.Areas.MiniGame.Models
{
    public class WalletSummaryReadModel
    {
        public int TotalUsers { get; set; }
        public int TotalPoints { get; set; }
        public decimal AveragePoints { get; set; }
        public int VipMembers { get; set; }
    }

    public class WalletReadModel
    {
        public int UserId { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string UserNickName { get; set; } = string.Empty;
        public int UserPoint { get; set; }
        public DateTime? LastUpdated { get; set; }
    }

    public class WalletDetailReadModel
    {
        public int UserId { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string UserNickName { get; set; } = string.Empty;
        public int UserPoint { get; set; }
        public DateTime? LastUpdated { get; set; }
    }

    public class WalletQueryModel
    {
        public string Search { get; set; } = string.Empty;
        public int? MinPoints { get; set; }
        public int? MaxPoints { get; set; }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 10;
    }

    public class SignInSummaryReadModel
    {
        public int TotalSignIns { get; set; }
        public int TodaySignIns { get; set; }
        public decimal AverageSignInsPerUser { get; set; }
        public int ConsecutiveDays { get; set; }
        
        // 添加視圖需要的屬性名稱
        public int TotalCount => TotalSignIns;
        public int TodayCount => TodaySignIns;
    }

    public class SignInStatsReadModel
    {
        public int UserId { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string UserNickName { get; set; } = string.Empty;
        public int SignInCount { get; set; }
        public DateTime SignTime { get; set; }
        public int ConsecutiveDays { get; set; }
    }

    public class UserSignInHistoryReadModel
    {
        public int UserId { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string UserNickName { get; set; } = string.Empty;
        public DateTime SignTime { get; set; }
        public int SignInCount { get; set; }
    }

    public class SignInQueryModel
    {
        public string Search { get; set; } = string.Empty;
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 10;
    }

    public class PetSummaryReadModel
    {
        public int TotalPets { get; set; }
        public int ActivePets { get; set; }
        public int InactivePets { get; set; }
        public decimal AverageLevel { get; set; }
    }

    public class PetReadModel
    {
        public int PetId { get; set; }
        public string PetName { get; set; } = string.Empty;
        public string PetStatus { get; set; } = string.Empty;
        public int PetLevel { get; set; }
        public int PetExp { get; set; }
        public bool IsActive { get; set; }
        public string OwnerName { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
    }

    public class PetDetailReadModel
    {
        public int PetId { get; set; }
        public string PetName { get; set; } = string.Empty;
        public string PetStatus { get; set; } = string.Empty;
        public int PetLevel { get; set; }
        public int PetExp { get; set; }
        public bool IsActive { get; set; }
        public int OwnerId { get; set; }
        public string OwnerName { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public DateTime? LastUpdated { get; set; }
    }

    public class PetQueryModel
    {
        public string Search { get; set; } = string.Empty;
        public int? MinLevel { get; set; }
        public int? MaxLevel { get; set; }
        public bool? IsActive { get; set; }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 10;
    }

    public class GameSummaryReadModel
    {
        public int TotalGames { get; set; }
        public int TodayGames { get; set; }
        public int TotalWins { get; set; }
        public int TotalLosses { get; set; }
        public int TotalAborts { get; set; }
        public decimal WinRate { get; set; }
        public int TotalPointsEarned { get; set; }
        
        // 添加視圖需要的屬性名稱
        public int TotalCount => TotalGames;
        public int TodayCount => TodayGames;
    }

    public class GameQueryModel
    {
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Result { get; set; } = string.Empty;
        public int? Level { get; set; }
        public int? UserId { get; set; }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 10;
    }

    public class GameRecordReadModel
    {
        public int PlayId { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string UserNickName { get; set; } = string.Empty;
        public int CardLevel { get; set; }
        public string GameResult { get; set; } = string.Empty;
        public int PointsEarned { get; set; }
        public bool PetInfluence { get; set; }
        public DateTime PlayedAt { get; set; }
    }

    public class GameDetailReadModel
    {
        public int PlayId { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string UserNickName { get; set; } = string.Empty;
        public int CardLevel { get; set; }
        public string GameResult { get; set; } = string.Empty;
        public int PointsEarned { get; set; }
        public bool PetInfluence { get; set; }
        public DateTime PlayedAt { get; set; }
        public string GameData { get; set; } = string.Empty;
    }
}
