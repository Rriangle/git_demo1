using GameSpace.Models;

namespace GameSpace.Areas.MiniGame.Models
{
    public class UserInfoReadModel
    {
        public int UserId { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string UserNickName { get; set; } = string.Empty;
        public string UserAccount { get; set; } = string.Empty;
        public bool UserEmailConfirmed { get; set; }
        public bool UserPhoneNumberConfirmed { get; set; }
        public DateTime? LastSignIn { get; set; }
        public int TotalSignIns { get; set; }
        public int ConsecutiveDays { get; set; }
    }

    public class TopUserReadModel
    {
        public int UserId { get; set; }
        public string UserName { get; set; } = string.Empty;
        public string UserNickName { get; set; } = string.Empty;
        public int SignInCount { get; set; }
        public int ConsecutiveDays { get; set; }
        public DateTime LastSignIn { get; set; }
    }
}
