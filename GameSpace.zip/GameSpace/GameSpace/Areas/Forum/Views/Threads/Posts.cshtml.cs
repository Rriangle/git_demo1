using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GameSpace.Areas.Forum.Views.Threads
{
    public class PostsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
